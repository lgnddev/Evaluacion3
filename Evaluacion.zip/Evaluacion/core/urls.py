from django.urls import path
from .views import home, registro, agregar, form_del_libro, modificar

urlpatterns = [
    path('', home, name="home"),
    path('registro', registro, name="registro"),
    path('agregar', agregar, name="agregar"),
    path('form-del-libro/<id>', form_del_libro, name="form_del_libro"),
    path('modificar/<id>', modificar, name="modificar")
]